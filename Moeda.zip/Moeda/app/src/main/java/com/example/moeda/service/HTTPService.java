package com.example.moeda.service;

import android.os.AsyncTask;

import com.example.moeda.model.Moeda;
import com.google.gson.Gson;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class HTTPService extends AsyncTask<Void, Void, Moeda> {

    private final String option;

    public HTTPService(String option) {
        this.option = option;
    }

    @Override
    protected Moeda doInBackground(Void... voids) {

        StringBuilder rs = new StringBuilder();

        try {

            URL url = new URL("https://economia.awesomeapi.com.br/json/"+option+"");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);
            connection.setConnectTimeout(5000);
            connection.connect();

            Scanner scanner = new Scanner(url.openStream());

            while (scanner.hasNext()){

                rs.append(scanner.next());

            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println(rs.toString());

        return new Gson().fromJson(rs.toString().replace("[","").replace("]",""), Moeda.class);
    }
}
