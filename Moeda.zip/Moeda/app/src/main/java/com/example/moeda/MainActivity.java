package com.example.moeda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.moeda.model.Moeda;
import com.example.moeda.service.HTTPService;

import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    private String[] moedas = new String[]{"USD-BRL","EUR-BRL","BTC-BRL","USDT-BRL","CAD-BRL","AUD-BRL","GBP-BRL","ARS-BRL",
                                            "JPY-BRL","CHF-BRL","CNY-BRL","LTC-BRL","ETH-BRL","XRP-BRL"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, moedas);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Spinner sp = (Spinner) findViewById(R.id.listaMoedas);
        sp.setAdapter(adapter);

        final TextView textResposta = findViewById(R.id.textResposta);
        final Spinner spSelect = findViewById(R.id.listaMoedas);

        Button btnDolar = findViewById(R.id.btnDolar);

        btnDolar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String option = spSelect.getSelectedItem().toString();

                HTTPService service = new HTTPService(option);

                try {

                    Moeda moeda = service.execute().get();
                    textResposta.setText(moeda.toString());

                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}